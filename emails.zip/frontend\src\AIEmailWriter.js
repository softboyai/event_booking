import React, { useState } from 'react';

export default function AIEmailWriter() {
  const [emailType, setEmailType] = useState("Business");
  const [subject, setSubject] = useState("");
  const [details, setDetails] = useState("");
  const [senderName, setSenderName] = useState("");
  const [senderCompany, setSenderCompany] = useState("");
  const [recipientName, setRecipientName] = useState("");
  const [recipientCompany, setRecipientCompany] = useState("");
  const [tone, setTone] = useState("Professional");
  const [emailContent, setEmailContent] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [loading, setLoading] = useState(false);

  // Generate email using AI
  const generateEmail = async () => {
    setLoading(true);
    try {
      const response = await fetch("http://localhost:5000/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email_type: emailType,
          subject,
          details,
          sender_name: senderName,
          sender_company: senderCompany,
          recipient_name: recipientName,
          recipient_company: recipientCompany,
          tone
        }),
      });
      const data = await response.json();
      setEmailContent(data.email_content);
    } catch (error) {
      console.error("Error generating email:", error);
    }
    setLoading(false);
  };

  // Send the generated (and optionally edited) email via Gmail API
  const sendEmail = async () => {
    try {
      const response = await fetch("http://127.0.0.1:5000/send_email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipient_email: recipientEmail,
          subject,
          email_body: emailContent,
        }),
      });
      const data = await response.json();
      if (data.message) {
        alert(data.message);
      } else {
        alert("Error: " + data.error);
      }
    } catch (error) {
      console.error("Error sending email:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center p-6">
      <div className="bg-white shadow-xl rounded-lg p-8 max-w-3xl w-full">
        <h1 className="text-3xl font-bold text-center mb-6">AI Email Writer</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            type="text"
            placeholder="Your Name"
            value={senderName}
            onChange={(e) => setSenderName(e.target.value)}
            className="border rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="text"
            placeholder="Your Company"
            value={senderCompany}
            onChange={(e) => setSenderCompany(e.target.value)}
            className="border rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="text"
            placeholder="Recipient Name"
            value={recipientName}
            onChange={(e) => setRecipientName(e.target.value)}
            className="border rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="text"
            placeholder="Recipient Company"
            value={recipientCompany}
            onChange={(e) => setRecipientCompany(e.target.value)}
            className="border rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="mt-4">
          <select
            value={emailType}
            onChange={(e) => setEmailType(e.target.value)}
            className="border rounded p-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="Business">Business Email</option>
            <option value="Marketing">Marketing Email</option>
          </select>
        </div>

        <div className="mt-4">
          <input
            type="text"
            placeholder="Enter subject..."
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="border rounded p-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="mt-4">
          <textarea
            placeholder="Enter details..."
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            className="border rounded p-2 w-full h-24 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="mt-4">
          <select
            value={tone}
            onChange={(e) => setTone(e.target.value)}
            className="border rounded p-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="Professional">Professional</option>
            <option value="Friendly">Friendly</option>
            <option value="Persuasive">Persuasive</option>
          </select>
        </div>

        <div className="mt-6 flex justify-center">
          <button
            onClick={generateEmail}
            className="bg-blue-600 text-white font-bold py-2 px-6 rounded shadow hover:bg-blue-700 transition duration-300"
          >
            {loading ? "Generating..." : "Generate Email"}
          </button>
        </div>

        {emailContent && (
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">Generated Email</h2>
            <textarea
              value={emailContent}
              onChange={(e) => setEmailContent(e.target.value)}
              className="border rounded p-2 w-full h-40 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <input
              type="email"
              placeholder="Recipient Email Address"
              value={recipientEmail}
              onChange={(e) => setRecipientEmail(e.target.value)}
              className="border rounded p-2 w-full mt-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <div className="mt-4 flex justify-center">
              <button
                onClick={sendEmail}
                className="bg-green-600 text-white font-bold py-2 px-6 rounded shadow hover:bg-green-700 transition duration-300"
              >
                Send Email
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
