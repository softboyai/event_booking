import os
import base64
import openai
from flask import Flask, request, jsonify
from flask_cors import CORS
from email.mime.text import MIMEText
from google.oauth2 import service_account
from googleapiclient.discovery import build

app = Flask(__name__)
CORS(app)  # Enable CORS to allow requests from the frontend

# --- OpenAI Configuration ---
openai.api_key = "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"  # Replace with your actual API key

# --- Gmail API Configuration ---
SCOPES = ['https://www.googleapis.com/auth/gmail.send']
CREDENTIALS_FILE = os.path.join(os.path.dirname(__file__), 'credentials.json')
creds = service_account.Credentials.from_service_account_file(CREDENTIALS_FILE, scopes=SCOPES)
gmail_service = build('gmail', 'v1', credentials=creds)

# --- Default Route ---
@app.route('/')
def index():
    return "Welcome to the AI Email Writer API!"

# --- Endpoint to Generate AI Email ---
@app.route('/generate_email', methods=['POST'])
def generate_email():
    data = request.json
    email_type = data.get("email_type", "Business")
    subject = data.get("subject", "General Inquiry")
    details = data.get("details", "No additional information provided.")
    sender_name = data.get("sender_name", "Your Name")
    sender_company = data.get("sender_company", "Your Company")
    recipient_name = data.get("recipient_name", "Dear Customer")
    recipient_company = data.get("recipient_company", "Their Company")
    tone = data.get("tone", "Professional")

    prompt = (
        f"Write a {tone} {email_type} email from {sender_name} at {sender_company} "
        f"to {recipient_name} at {recipient_company}. Subject: {subject}. "
        f"Details: {details}"
    )

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an AI email writer."},
            {"role": "user", "content": prompt}
        ]
    )
    email_content = response['choices'][0]['message']['content']
    return jsonify({"email_content": email_content})

# --- Endpoint to Send Email using Gmail API ---
@app.route('/send_email', methods=['POST'])
def send_email():
    data = request.json
    recipient_email = data.get("recipient_email", "example@example.com")
    subject = data.get("subject", "AI Generated Email")
    email_body = data.get("email_body", "This is an AI-generated email.")

    # Create a MIMEText email message
    message = MIMEText(email_body)
    message['to'] = recipient_email
    message['subject'] = subject

    raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()

    try:
        gmail_service.users().messages().send(userId="me", body={"raw": raw_message}).execute()
        return jsonify({"message": "Email sent successfully!"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
