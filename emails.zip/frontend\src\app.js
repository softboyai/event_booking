import React from 'react';
import AIEmailWriter from './AIEmailWriter';

function App() {
  return (
    <div>
      <AIEmailWriter />
    </div>
  );
}

export default App;
